//
//  MemeStruct.swift
//  MemeMeV1
//
//  Created by Johannes Dierkes on 02.05.17.
//  Copyright © 2017 Johannes Dierkes. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    
    let topText:String
    let bottomText:String
    let originalImage:UIImage
    let memedImage:UIImage

}
